/**
 * An interface that represents a way of displaying a Board
 */
public interface Renderer{
    void renderBoard(Board board);

}
